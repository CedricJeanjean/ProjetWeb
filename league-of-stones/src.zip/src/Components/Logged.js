import '../App.css';
import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';


function Logged(){
    return (
       
        <div>
            <button id="logout">Lancer la recherche</button>
        </div>
        
    )
}

export default Logged;